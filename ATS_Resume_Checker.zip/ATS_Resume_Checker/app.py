from flask import Flask, render_template, request
import PyPDF2
import re
app = Flask(__name__)
ATS_KEYWORDS = [
    "python", "sql", "git", "analysis", "testing",
    "data", "machine learning", "communication",
    "problem solving", "teamwork", "flask",
    "html", "css", "javascript", "mysql"
]
ACTION_VERBS = [
    "developed", "implemented", "designed",
    "analyzed", "created", "managed",
    "led", "improved", "optimized"
]
REQUIRED_SECTIONS = [
    "education", "skills", "experience", "projects"
]
@app.route("/")
def home():
    return render_template("index.html")
@app.route("/analyze", methods=["POST"])
def analyze(): 
    if "resume" not in request.files:
        return "No file uploaded."
    file = request.files["resume"]
    if file.filename == "":
        return "No file selected."
    try:
        reader = PyPDF2.PdfReader(file)
    except:
        return "Invalid PDF file."
    text = ""
    for page in reader.pages:
        extracted = page.extract_text()
        if extracted:
            text += extracted.lower()
    if text.strip() == "":
        return "Cannot read text from this PDF. Use text-based PDF."
    words = text.split()
    word_count = len(words)
    score = 0
    feedback = []
    missing_keywords = []
    matched = 0
    for keyword in ATS_KEYWORDS:
        if keyword in text:
            matched += 1
        else:
            missing_keywords.append(keyword)
    keyword_score = int((matched / len(ATS_KEYWORDS)) * 50)
    score += keyword_score
    if 300 <= word_count <= 700:
        score += 10
    else:
        feedback.append("Resume should be 300–700 words.")
    action_count = sum(1 for verb in ACTION_VERBS if verb in text)
    if action_count >= 3:
        score += 15
    else:
        feedback.append("Add strong action verbs like Developed, Implemented.")
    section_count = sum(1 for sec in REQUIRED_SECTIONS if sec in text)
    if section_count >= 3:
        score += 15
    else:
        feedback.append("Include Education, Skills, Experience, Projects sections.")
    if re.search(r"\b\d{10}\b", text) and "@" in text:
        score += 10
    else:
        feedback.append("Add valid phone number and email.")
    if score >= 80:
        status = "Excellent - Highly ATS Friendly"
    elif score >= 60:
        status = "Good - Moderately ATS Friendly"
    elif score >= 40:
        status = "Average - Needs Improvement"
    else:
        status = "Poor - Not ATS Friendly"
    if missing_keywords:
        feedback.append("Missing keywords: " + ", ".join(missing_keywords[:5]))
    return render_template(
        "result.html",
        score=score,
        status=status,
        word_count=word_count,
        keyword_score=keyword_score,
        feedback=feedback
    )
if __name__ == "__main__":
    app.run(debug=True)